# AristAI Hands-Free Voice System

A truly hands-free conversational voice interface for AristAI instructors and administrators.

## What's Included

```
aristai-hands-free-voice/
├── README.md                    # This file
├── frontend/
│   └── src/
│       ├── components/
│       │   ├── AppShellHandsFree.tsx    # Main app shell with voice integration
│       │   └── voice/
│       │       ├── index.ts              # Component exports
│       │       ├── ConversationalVoice.tsx   # Always-on voice assistant
│       │       ├── VoiceOnboarding.tsx       # Voice-dismissable welcome
│       │       ├── VoiceWaveformMini.tsx     # Mini waveform for header
│       │       └── ... (other voice components)
│       └── lib/
│           └── api-additions.ts          # API endpoint additions
└── backend/
    └── voice_converse_router.py          # Conversational backend endpoint
```

## Features

### 1. Voice-Dismissable Onboarding
- First-time instructors see a welcome modal
- The AI speaks the welcome message
- User says "Got it", "Okay", "Let's go" (or similar) to dismiss
- No clicking required!

### 2. Always-On Voice Assistant
- Automatically starts listening after login (for instructors)
- Continuous listening with voice activity detection
- Automatically detects when you stop speaking
- Natural conversational responses

### 3. Conversational AI
Instead of robotic responses like:
> "I successfully retrieved the course list..."

You get natural dialogue like:
> "You have 3 courses: STAT 480, ASRM 410, and Costos y Presupuestos. Would you like me to open one, or start a session?"

### 4. Voice Navigation
- "Go to courses" → Navigates to /courses
- "Open the forum" → Navigates to /forum
- "Take me to the console" → Navigates to /console

### 5. Voice Commands
- "Show my courses" → Lists courses with context
- "Start the copilot" → Activates AI copilot
- "Create a poll" → Offers to help create a poll
- "Generate a report" → Starts report generation

## Installation

### Frontend

1. **Copy voice components:**
```bash
cp -r frontend/src/components/voice/* your-project/frontend/src/components/voice/
cp frontend/src/components/AppShellHandsFree.tsx your-project/frontend/src/components/
```

2. **Add API method to `lib/api.ts`:**
```typescript
// Add to your api object:
voiceConverse: async (request: {
  transcript: string;
  context?: string[];
  user_id?: number;
  current_page?: string;
}): Promise<{
  message: string;
  action?: { type: string; target?: string; executed?: boolean };
  results?: any[];
  suggestions?: string[];
}> => {
  return fetchApi('/voice/converse', {
    method: 'POST',
    body: JSON.stringify(request),
  });
},
```

3. **Update dashboard layout to use hands-free shell:**
```tsx
// frontend/src/app/(dashboard)/layout.tsx
'use client';

import { AppShellHandsFree } from '@/components/AppShellHandsFree';
import { AuthProvider } from '@/lib/auth-context';
import { UserProvider } from '@/lib/context';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AuthProvider>
      <UserProvider>
        <AppShellHandsFree>{children}</AppShellHandsFree>
      </UserProvider>
    </AuthProvider>
  );
}
```

### Backend

1. **Add the conversational router to your API:**
```python
# In your main router.py or app.py
from .voice_converse_router import router as voice_converse_router

app.include_router(voice_converse_router)
```

2. **Connect to your MCP server:**

Edit `voice_converse_router.py` and replace the mock implementations in `execute_action()` with actual calls to your MCP server or database.

```python
async def execute_action(action: str, user_id: Optional[int], current_page: Optional[str]) -> Optional[Any]:
    if action == 'list_courses':
        # Replace with actual implementation:
        from your_app.api import get_courses
        return await get_courses()
    # ... etc
```

## How It Works

### Voice Flow

```
User logs in
    ↓
[First time?] → Show VoiceOnboarding
    ↓              ↓
    ↓         AI speaks welcome
    ↓              ↓
    ↓         Listen for "Got it"
    ↓              ↓
    ↓         Dismiss & continue
    ↓
ConversationalVoice starts
    ↓
Always listening (with VAD)
    ↓
User speaks → Detect silence → Process
    ↓
Transcribe → Detect intent → Execute/Navigate
    ↓
Speak response → Resume listening
```

### Voice Activity Detection (VAD)

The system uses a simple but effective VAD:
- Monitors audio levels in real-time
- Tracks when audio exceeds threshold (speech)
- Waits for 1.5 seconds of silence after speech
- Then processes the accumulated audio

Configurable settings:
- `sensitivity`: Audio threshold (default: 0.02)
- `silenceTimeout`: Ms of silence before processing (default: 1500)

### Intent Detection

The backend detects two types of intents:

1. **Navigation** - User wants to go somewhere:
   - "go to courses" → `/courses`
   - "open forum" → `/forum`
   - "take me to console" → `/console`

2. **Action** - User wants to do something:
   - "list my courses" → Fetch and describe courses
   - "start copilot" → Start the AI copilot
   - "create poll" → Offer poll creation help

## Customization

### Adding New Voice Commands

In `voice_converse_router.py`:

```python
# Add to ACTION_PATTERNS:
ACTION_PATTERNS = {
    # ... existing patterns ...
    'my_new_action': [
        r'\bmy custom phrase\b',
        r'\banother phrase\b',
    ],
}

# Then handle it in execute_action():
async def execute_action(action: str, ...):
    if action == 'my_new_action':
        # Do something
        return result
```

### Changing the Wake Behavior

By default, the system is always listening. To change to wake-word mode, modify `ConversationalVoice.tsx`:

```tsx
// Change autoStart to false
<ConversationalVoice
  autoStart={false}  // Don't auto-start
  // Add wake word detection logic
/>
```

### Customizing Responses

Edit `generate_conversational_response()` in `voice_converse_router.py` to change how the AI responds to different actions.

## Troubleshooting

### "Microphone access denied"
- Check browser permissions
- Ensure HTTPS in production

### Voice not detecting speech
- Adjust `sensitivity` setting (lower = more sensitive)
- Check microphone levels in system settings

### Responses too slow
- The system waits for silence before processing
- Reduce `silenceTimeout` for faster response (but may cut off speech)

### Echo/feedback issues
- The system pauses listening while speaking
- If issues persist, ensure `echoCancellation: true` is set

## Browser Support

- Chrome 49+ (recommended)
- Firefox 29+
- Safari 14.1+
- Edge 79+

Web Speech API (for text-to-speech) is supported in all modern browsers.
