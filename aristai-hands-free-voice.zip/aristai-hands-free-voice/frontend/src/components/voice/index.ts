// Original components
export { VoiceAssistant } from './VoiceAssistant';
export type { VoiceAssistantProps, VoiceMode, VoiceState } from './VoiceAssistant';
export { VoiceWaveform } from './VoiceWaveform';
export { VoicePlanPreview } from './VoicePlanPreview';
export { VoiceSettings } from './VoiceSettings';
export { VoiceHistory } from './VoiceHistory';
export { VoiceFab } from './VoiceFab';
export { VoiceTabContent } from './VoiceTabContent';

// Hands-free conversational components
export { ConversationalVoice } from './ConversationalVoice';
export type { ConversationState } from './ConversationalVoice';
export { VoiceOnboarding } from './VoiceOnboarding';
export { VoiceWaveformMini } from './VoiceWaveformMini';
