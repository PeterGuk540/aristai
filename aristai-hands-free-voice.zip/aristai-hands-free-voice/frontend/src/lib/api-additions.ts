// Add these types and methods to your existing api.ts file

// ============ TYPES TO ADD ============

export interface VoiceConverseRequest {
  transcript: string;
  context?: string[];
  user_id?: number;
  current_page?: string;
}

export interface VoiceConverseResponse {
  message: string;
  action?: {
    type: 'navigate' | 'execute' | 'info';
    target?: string;
    executed?: boolean;
  };
  results?: any[];
  suggestions?: string[];
}

// ============ API METHOD TO ADD ============

// Add this to your api object:

  /**
   * Conversational voice endpoint - handles natural language and returns
   * conversational responses with optional actions
   */
  voiceConverse: async (request: VoiceConverseRequest): Promise<VoiceConverseResponse> => {
    return fetchApi<VoiceConverseResponse>('/voice/converse', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  },
